---
title: Creator Dashboard
description: Build a floating Creator Dashboard (stats, quick actions, billboard UI) for the local game.
version: 1.0.0
---

# Creator Dashboard

A skill for building a developer dashboard overlay in Roblox Studio Lite: a
resizable ScreenGui panel that shows live server stats and gives one-click
quick actions (spawn, reset, toggle god mode).

Use this skill when the user asks to "make a dashboard", "build a creator
panel", "add an admin toolbar", or similar.

## How to use

1. Ask the user where to mount the dashboard (default: top-right corner).
2. Use `run_luau` with the helper `scripts/build_dashboard.luau` to construct
   the ScreenGui, MainFrame, and its UIListLayout-based rows.
3. Wire quick-action buttons to a small `Script` (see `scripts/actions.luau`)
   and parent it under the ScreenGui. The agent may need to run the script's
   code via `run_luau` instead of creating a real Script if the game uses an
   executor sandbox.
4. Confirm the dashboard is visible and interactive.

## Layout contract

- `ScreenGui` named `CreatorDashboard` with `IgnoreGuiInset = true`.
- Root `Frame` anchored top-right (`AnchorPoint = (1, 0)`), size 240x360,
  semi-transparent dark background (`BackgroundColor3 = Color3.fromRGB(20,22,28)`,
  `BackgroundTransparency = 0.15`).
- A `UIListLayout` with `Padding = UDim.new(0, 6)` for stacked rows.
- Quick-action buttons call a shared `module` you keep in the same folder.

## Requirements

- All instances must be created inside the game via `run_luau` or `insert_part`.
- Use only built-in Luau and Roblox APIs. No external packages.
- Keep part/UI names unique to avoid collisions on repeated runs.
