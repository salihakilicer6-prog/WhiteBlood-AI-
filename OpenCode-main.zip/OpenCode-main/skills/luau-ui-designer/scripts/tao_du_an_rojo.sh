#!/usr/bin/env bash
# Sinh cấu trúc dự án Rojo mới cho UI Roblox.
# Cách dùng: tao_du_an_rojo.sh <tên-thư-mục>
set -e

if [ $# -lt 1 ]; then
  echo "Cách dùng: $0 <tên-thư-mục>"
  exit 1
fi

TEN="$1"
mkdir -p "$TEN/src/StarterGui" "$TEN/src/ReplicatedStorage" "$TEN/src/types"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cat > "$TEN/.luaurc" << 'LUARC'
{
    "aliases": {
        "ui": "./src"
    }
}
LUARC

cat > "$TEN/default.project.json" << 'PROJ'
{
  "name": "MenuUI",
  "tree": {
    "$path": "src",
    "StarterGui": {
      "$path": "src/StarterGui"
    },
    "ReplicatedStorage": {
      "$path": "src/ReplicatedStorage"
    }
  }
}
PROJ

cp "$SCRIPT_DIR/../references/roblox-types.luau" "$TEN/src/types/roblox.luau"

cat > "$TEN/src/StarterGui/MenuGui.client.luau" << 'LUAGUI'
--!strict
-- LocalScript: Menu chính. Chỉnh sửa theo thiết kế ở Bước 1.
local roblox = require("../types/roblox")
local game = roblox.game
local Instance = roblox.Instance
local UDim = roblox.UDim
local UDim2 = roblox.UDim2
local Vector2 = roblox.Vector2
local TweenService = roblox.TweenService

local Players = game:GetService("Players")
local UIConfig = require("../ReplicatedStorage/UIConfig")

local playerGui = Players.LocalPlayer:WaitForChild("PlayerGui")

local screen = Instance.new("ScreenGui")
screen.Name = "MenuChinh"
screen.Parent = playerGui

local khung = Instance.new("Frame")
khung.Size = UDim2.fromOffset(300, 200)
khung.Position = UDim2.fromScale(0.5, 0.5)
khung.AnchorPoint = Vector2.new(0.5, 0.5)
khung.BackgroundColor3 = UIConfig.mauNen
khung.Parent = screen

local boGoc = Instance.new("UICorner")
boGoc.CornerRadius = UDim.new(0, 12)
boGoc.Parent = khung

local nut = Instance.new("TextButton")
nut.Size = UDim2.fromOffset(260, 50)
nut.Position = UDim2.fromScale(0.5, 0.4)
nut.AnchorPoint = Vector2.new(0.5, 0.5)
nut.BackgroundColor3 = UIConfig.mauChuDao
nut.Text = "Bắt đầu"
nut.TextColor3 = UIConfig.mauChu
nut.Font = UIConfig.font
nut.TextSize = 20
nut.Parent = khung

local ketNoi = nut.MouseButton1Click:Connect(function()
  print("Đã bấm Bắt đầu")
end)

local _tween = TweenService
screen.Destroying:Connect(function()
  if ketNoi then ketNoi:Disconnect() end
end)
LUAGUI

cat > "$TEN/src/ReplicatedStorage/UIConfig.luau" << 'LUACONFIG'
--!strict
-- ModuleScript: cấu hình chung cho UI.
local roblox = require("../types/roblox")
local Color3 = roblox.Color3
local Enum = roblox.Enum

local UIConfig = {
  mauNen = Color3.fromRGB(30, 30, 35),
  mauChuDao = Color3.fromRGB(70, 130, 230),
  mauChu = Color3.fromRGB(240, 240, 240),
  font = Enum.Font.GothamMedium,
}

return UIConfig
LUACONFIG

cat > "$TEN/README.md" << 'README'
# MenuUI

Dự án Rojo cho UI Roblox, hỗ trợ kiểm tra type bằng luau-analyze.

## Chạy preview (Rojo)

```bash
rojo serve
```

Rojo in ra một cổng (ví dụ `http://localhost:34872`). Mở Roblox Studio, vào
Rojo Manager, nhập cổng đó để đồng bộ. Mọi thay đổi trong `src/` tự cập nhật.

## Kiểm tra type và lint (luau-analyze)

```bash
luau-analyze --mode=strict src/StarterGui/MenuGui.client.luau
```

File `src/types/roblox.luau` cung cấp định nghĩa type cho API Roblox. Mỗi file UI
require file này ở đầu để luau-analyze nhận biết `game`, `Instance`, `Color3`...

## Chạy logic bằng executor

```bash
luau ../scripts/executor.luau
```

Executor mô phỏng API Roblox trong terminal (không render hình) để kiểm tra logic
không phụ thuộc Studio. Để chạy file UI riêng, copy `executor.luau` vào dự án,
sửa phần nhúng code UI ở cuối file rồi chạy `luau run.luau`.

## Cấu trúc

- `default.project.json` - cấu hình Rojo.
- `.luaurc` - cấu hình alias cho luau-analyze (`@ui` trỏ tới `./src`).
- `src/types/roblox.luau` - định nghĩa type Roblox cho luau-analyze.
- `src/StarterGui/MenuGui.client.luau` - LocalScript chứa UI (chạy trên client).
- `src/ReplicatedStorage/UIConfig.luau` - ModuleScript cấu hình (màu, font).
README

echo "Đã tạo dự án Rojo tại: $TEN"
echo "Tiếp theo:"
echo "  cd $TEN"
echo "  luau-analyze --mode=strict src/StarterGui/MenuGui.client.luau"
echo "  rojo serve"
