#!/usr/bin/env bash
# Kiểm tra xem luau CLI đã cài chưa, in hướng dẫn nếu chưa.
set -e

if command -v luau >/dev/null 2>&1; then
  echo "luau CLI đã cài: $(luau --version 2>&1 || echo 'không rõ phiên bản')"
  echo "Đường dẫn: $(command -v luau)"
  exit 0
fi

echo "luau CLI chưa cài."
echo ""
echo "Cách cài:"
echo "  1. Tải binary 'luau' từ repos luau-lang/luau trên GitHub."
echo "  2. Nếu có Rust:  cargo install luau-cli"
echo "  3. Termux (Android): pkg install luau  (nếu gói có sẵn)"
echo ""
echo "Sau khi cài, chạy lại script này để xác nhận."
exit 1
