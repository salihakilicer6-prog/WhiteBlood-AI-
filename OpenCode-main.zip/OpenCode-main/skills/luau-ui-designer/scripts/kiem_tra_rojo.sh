#!/usr/bin/env bash
# Kiểm tra xem Rojo đã cài chưa, in hướng dẫn nếu chưa.
set -e

if command -v rojo >/dev/null 2>&1; then
  echo "Rojo đã cài: $(rojo --version 2>&1 || echo 'không rõ phiên bản')"
  echo "Đường dẫn: $(command -v rojo)"
  exit 0
fi

echo "Rojo chưa cài."
echo ""
echo "Cách cài (chọn một):"
echo "  1. Tải binary từ repos rojo trên GitHub, giải nén và cho vào PATH."
echo "  2. Nếu có Rust:  cargo install rojo"
echo "  3. Termux (Android, nếu có gói): pkg install rojo"
echo ""
echo "Sau khi cài, chạy lại script này để xác nhận."
exit 1
