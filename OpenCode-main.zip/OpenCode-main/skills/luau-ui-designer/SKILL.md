---
name: luau-ui-designer
description: |
  Thiết kế giao diện (UI) Roblox bằng Luau theo ba bước: Designer UI (bố cục,
  màu, font), Preview Rojo (xem trước trong Studio, kèm phương án mobile), và
  Luau in UI (nhúng logic vào giao diện). Đi kèm luau executor để chạy và kiểm
  tra code trong terminal, cùng file định nghĩa type cho luau-analyze. Dùng khi
  cần tạo menu, HUD, nút bấm, thông báo, popup, animation UI cho Roblox, hoặc khi
  nhắc tới ScreenGui, Frame, TextButton, Rojo, preview UI, executor Luau. Toàn
  bộ hướng dẫn bằng tiếng Việt.
license: MIT
metadata:
  version: "1.0.0"
  ngôn_ngữ: vi
  engine: roblox
  category: ui-design
  difficulty: intermediate
---

# Luau UI Designer

Thiết kế UI Roblox bằng Luau theo ba bước: Designer UI, Preview Rojo, Luau in UI.
Skill đi kèm executor chạy trong terminal và file type cho `luau-analyze`.

## Khi nào dùng

- Tạo menu, HUD, thanh máu, nút bấm, thông báo, popup, bảng cài đặt cho Roblox.
- Người dùng nhắc `ScreenGui`, `Frame`, `TextButton`, `TextLabel`, `UICorner`,
  `UIStroke`, `TweenService`, `Rojo`, `default.project.json`, hoặc muốn preview UI.
- Cần chuyển một bản phác thảo (text, ảnh, mô tả) thành giao diện Roblox chạy được.
- Muốn chạy thử và kiểm tra type code Luau trong terminal mà không cần mở Studio.

**Khi không dùng:** lưu dữ liệu người chơi, logic server thuần, hoặc câu hỏi Lua
chung không liên quan tới giao diện Roblox.

## Quy trình ba bước

Đi theo đúng thứ tự. Mỗi bước có đầu ra riêng, bước sau phụ thuộc bước trước.

### Bước 1: Designer UI

Bước này chỉ thiết kế, chưa viết code. Chốt bố cục và phong cách trước khi chạm
vào Luau, giống vẽ bản nháp trước khi xây.

1. **Thu thập yêu cầu.** Hỏi (hoặc suy ra từ mô tả) loại UI, kích thước, số nút,
   nội dung chữ, màu chủ đạo, phong cách (tối giản, game, neon). Nếu người dùng
   đưa ảnh phác thảo thì phân tích ảnh đó.
2. **Vẽ wireframe bằng text.** Dùng khung ASCII để người dùng thấy bố cục trước:

   ```
   ┌─ Menu chính ─────────────┐
   │  [Bắt đầu]              │
   │  [Cài đặt]              │
   │  [Thoát]                │
   └─────────────────────────┘
   ```

3. **Chốt bảng thiết kế.** Liệt kê: danh sách thành phần, màu (mã hex), font, cỡ
   chữ, bo góc, padding, hành vi khi bấm. Giữ bảng ngắn, chỉ ghi thuộc tính quyết
   định.
4. **Chọn loại GUI.** `ScreenGui` cho toàn màn hình, `BillboardGui` cho UI dính
   vào thế giới 3D, `SurfaceGui` cho UI dính vào mặt Part. Đa số menu dùng
   `ScreenGui`.
5. **Chốt trước khi qua bước 2.** Gọi tóm tắt thiết kế cho người dùng xác nhận.
   Đừng viết code Luau trong bước này.

### Bước 2: Preview Rojo

Sinh cấu trúc dự án Rojo để người dùng xem trước UI trong Studio mà không phải
copy-paste từng file. Rojo đồng bộ thư mục trên máy với Studio theo thời gian thực.

1. **Kiểm tra môi trường.** Chạy `scripts/kiem_tra_rojo.sh` để xem Rojo đã cài
   chưa. Nếu chưa có, script in hướng dẫn cài.
2. **Sinh dự án Rojo.** Chạy `scripts/tao_du_an_rojo.sh <tên-thư-mục>`. Script tạo:

   ```
   <tên-thư-mục>/
   ├── .luaurc                        -- alias @ui trỏ tới ./src
   ├── default.project.json           -- cấu hình Rojo
   ├── src/
   │   ├── StarterGui/
   │   │   └── MenuGui.client.luau    -- LocalScript chứa UI
   │   ├── ReplicatedStorage/
   │   │   └── UIConfig.luau          -- ModuleScript cấu hình (màu, font)
   │   └── types/
   │       └── roblox.luau            -- định nghĩa type Roblox cho luau-analyze
   └── README.md
   ```

3. **Kiểm tra type và lint.** Chạy `luau-analyze --mode=strict` cho file UI. File
   `src/types/roblox.luau` cho `luau-analyze` nhận biết `game`, `Instance`,
   `Color3`, `UDim2`... Mỗi file UI `require("../types/roblox")` ở đầu để nạp type.
4. **Chạy preview.** Chạy `rojo serve` trong thư mục dự án. Rojo in ra một cổng
   (ví dụ `http://localhost:34872`). Mở Roblox Studio, vào Rojo Manager, nhập cổng
   đó để đồng bộ. Mọi thay đổi trong `src/` tự cập nhật vào Studio.
5. **Phương án cho mobile.** Rojo cần máy tính để `serve`. Trên điện thoại, dùng
   phương án thay thế:
   - **Executor Luau kèm skill:** chạy `scripts/executor.luau` để kiểm tra logic UI
     (tạo instance, gán thuộc tính, nối sự kiện) trong terminal, không cần Studio.
     Executor không render hình nhưng nạp môi trường giả lập và in kết quả.
   - **`luau-analyze`:** chạy `luau-analyze --mode=strict <file.luau>` để bắt lỗi
     cú pháp và type ngay trên thiết bị có `luau-analyze` (qua termux trên Android).
   - **Roblox Studio trên PC khác:** đẩy code lên Studio rồi xem trước trên app
     Roblox mobile bằng tính năng Play.
6. **Lặp.** Người dùng xem preview, yêu cầu sửa, ta cập nhật `src/` và Rojo tự
   đồng bộ.

### Bước 3: Luau in UI

Nhúng logic Luau vào giao diện đã thiết kế. Mọi code đặt đúng vị trí trong cấu
trúc Rojo và tuân thủ nguyên tắc client/server.

1. **Đặt code đúng chỗ.** UI chạy trên client nên dùng `LocalScript` (đuôi
   `.client.luau`). Cấu hình dùng chung đặt trong `ReplicatedStorage` như
   `ModuleScript` (đuôi `.luau`).
2. **Nạp type ở đầu file.** Mỗi file UI thêm `local roblox = require("../types/roblox")`
   rồi lấy `game`, `Instance`, `Color3`... từ bảng `roblox`. Việc này giúp
   `luau-analyze` kiểm tra type đúng.
3. **Tạo instance theo thứ tự.** Tạo instance, gán thuộc tính, rồi gán `Parent`
   cuối cùng để tránh nhân bản không cần thiết.
4. **Dùng `UIConfig` cho cấu hình.** Đưa màu, font, kích thước vào `UIConfig.luau`
   để dễ đổi và giữ code UI gọn.
5. **Nối sự kiện.** Dùng `:Connect` cho `MouseButton1Click`, `MouseEnter`,
   `MouseLeave`. Ngắt kết nối khi xóa UI để tránh rò rỉ.
6. **Animation bằng `TweenService`.** Cho hiệu ứng mượt (đổi size, vị trí, độ
   trong suốt).
7. **Kiểm tra trước khi đẩy Studio.** Chạy `luau-analyze --mode=strict` cho file
   UI, sửa hết lỗi type và lint. Sau đó dùng preview Rojo để xem trực tiếp.

## Executor Luau

`scripts/executor.luau` nạp môi trường giả lập API Roblox trong terminal. Vì luau
CLI sandbox global (read-only) và không mở `io`, executor không đọc file từ arg.
Thay vào thế, nó cung cấp môi trường giả lập sẵn sàng để bạn nhúng code UI vào.

**Cách dùng:**

```bash
luau scripts/executor.luau
```

Executor in danh sách API đã mô phỏng và hướng dẫn nhúng code. Để chạy file UI
riêng, copy `executor.luau` vào dự án, sửa phần "NHÚNG CODE UI" ở cuối file rồi
chạy `luau run.luau`.

API đã mô phỏng: `game:GetService`, `Instance.new`, `Color3.fromRGB`,
`UDim2.fromScale`/`fromOffset`, `Vector2.new`, `TweenService:Create`,
`Signal:Connect`/`Disconnect`.

## Kiểm tra type bằng luau-analyze

`luau-analyze` kiểm tra cú pháp, type, và lint cho file Luau. Skill cung cấp
`references/roblox-types.luau` chứa định nghĩa type cho API Roblox. Khi sinh dự
án, script copy file này vào `src/types/roblox.luau`.

**Cách dùng:**

```bash
luau-analyze --mode=strict src/StarterGui/MenuGui.client.luau
```

Mỗi file UI `require("../types/roblox")` ở đầu để `luau-analyze` nhận biết
`game`, `Instance`, `Color3`... Nếu thêm API mới, cập nhật
`references/roblox-types.luau` cho khớp.

## Cài đặt công cụ

- **Rojo (PC):** tải binary từ repos rojo trên GitHub, hoặc `cargo install rojo`
  nếu có Rust. Rojo cần cổng mở để Studio kết nối.
- **Luau CLI + luau-analyze:** tải binary từ repos luau-lang/luau trên GitHub, hoặc
  build từ source bằng CMake. Cần `luau` để chạy executor và `luau-analyze` để
  kiểm tra type.
- **Termux (Android):** nếu gói `luau` có sẵn, `pkg install luau`. Nếu không, tải
  binary phù hợp hoặc build từ source.

## Mẫu code

### File type (sinh tự động)

```lua
-- src/types/roblox.luau
--!strict
export type Instance = { Name: string, Parent: any, Size: any, ... }
export type Game = { GetService: (Game, string) -> any }
return {
  game = (nil :: any) :: Game,
  Instance = (nil :: any) :: InstanceClass,
  Color3 = (nil :: any) :: Color3Lib,
  ...
}
```

### Tạo ScreenGui với một nút

```lua
-- src/StarterGui/MenuGui.client.luau
--!strict
local roblox = require("../types/roblox")
local game = roblox.game
local Instance = roblox.Instance
local UDim2 = roblox.UDim2
local Vector2 = roblox.Vector2

local Players = game:GetService("Players")
local UIConfig = require("../ReplicatedStorage/UIConfig")

local playerGui = Players.LocalPlayer:WaitForChild("PlayerGui")

local screen = Instance.new("ScreenGui")
screen.Name = "MenuChinh"
screen.ResetOnSpawn = false
screen.Parent = playerGui

local khung = Instance.new("Frame")
khung.Size = UDim2.fromOffset(300, 200)
khung.Position = UDim2.fromScale(0.5, 0.5)
khung.AnchorPoint = Vector2.new(0.5, 0.5)
khung.BackgroundColor3 = UIConfig.mauNen
khung.Parent = screen

local boGoc = Instance.new("UICorner")
boGoc.CornerRadius = UDim.new(0, 12)
boGoc.Parent = khung

local nutBatDau = Instance.new("TextButton")
nutBatDau.Size = UDim2.fromOffset(260, 50)
nutBatDau.Position = UDim2.fromScale(0.5, 0.4)
nutBatDau.AnchorPoint = Vector2.new(0.5, 0.5)
nutBatDau.BackgroundColor3 = UIConfig.mauChuDao
nutBatDau.Text = "Bắt đầu"
nutBatDau.TextColor3 = UIConfig.mauChu
nutBatDau.Font = UIConfig.font
nutBatDau.TextSize = 20
nutBatDau.Parent = khung

local ketNoi = nutBatDau.MouseButton1Click:Connect(function()
  print("Đã bấm Bắt đầu")
end)

screen.Destroying:Connect(function()
  if ketNoi then ketNoi:Disconnect() end
end)
```

### Module cấu hình

```lua
-- src/ReplicatedStorage/UIConfig.luau
--!strict
local roblox = require("../types/roblox")
local Color3 = roblox.Color3
local Enum = roblox.Enum

local UIConfig = {
  mauNen = Color3.fromRGB(30, 30, 35),
  mauChuDao = Color3.fromRGB(70, 130, 230),
  mauChu = Color3.fromRGB(240, 240, 240),
  font = Enum.Font.GothamMedium,
}

return UIConfig
```

## Lưu ý

- **Client/server:** UI chạy trên client, dùng `LocalScript`. Nếu cần thay đổi
  trạng thái game, dùng `RemoteEvent`/`RemoteFunction` và để server xác thực.
- **Parent cuối cùng:** gán `Parent` sau khi set xong thuộc tính để tránh nhân bản.
- **Ngắt kết nối:** khi xóa UI, ngắt mọi `:Connect` để tránh rò rỉ bộ nhớ.
- **Preview không thay Studio:** executor và `luau-analyze` chỉ kiểm tra logic và
  type. Kết quả chính xác vẫn phải xem trong Studio qua Rojo.
- **Chỉ sửa theo yêu cầu:** không tự ý đổi tên file hoặc biến nếu người dùng chưa
  yêu cầu.

## Tham chiếu file

- `scripts/kiem_tra_rojo.sh` - kiểm tra Rojo đã cài chưa.
- `scripts/kiem_tra_luau.sh` - kiểm tra luau CLI đã cài chưa.
- `scripts/tao_du_an_rojo.sh` - sinh cấu trúc dự án Rojo mới.
- `scripts/executor.luau` - executor Luau chạy trong terminal.
- `references/roblox-types.luau` - định nghĩa type Roblox cho luau-analyze.
