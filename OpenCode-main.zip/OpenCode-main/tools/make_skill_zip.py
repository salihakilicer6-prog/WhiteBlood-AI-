#!/usr/bin/env python3
"""Zip a skill folder from skills/ into dist/skills/<name>.zip so it can be
hosted and installed through the in-app Skills view (Skill.install downloads
and unzips it).

Usage:
    python3 tools/make_skill_zip.py creator-dashboard
    python3 tools/make_skill_zip.py --all
"""

import argparse
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKILLS_DIR = os.path.join(ROOT, "skills")
OUT_DIR = os.path.join(ROOT, "dist", "skills")


def make_zip(name):
    src = os.path.join(SKILLS_DIR, name)
    if not os.path.isdir(src):
        print(f"error: no skill folder at {src}")
        return None
    os.makedirs(OUT_DIR, exist_ok=True)
    out = os.path.join(OUT_DIR, name + ".zip")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for dirpath, dirnames, filenames in os.walk(src):
            for fn in sorted(filenames):
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, SKILLS_DIR).replace(os.sep, "/")
                zf.write(full, rel)
    print(f"wrote {os.path.relpath(out, ROOT)} ({os.path.getsize(out)} bytes)")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("names", nargs="*")
    ap.add_argument("--all", action="store_true")
    args = ap.parse_args()

    if args.all:
        names = [d for d in sorted(os.listdir(SKILLS_DIR))
                 if os.path.isdir(os.path.join(SKILLS_DIR, d))]
    elif args.names:
        names = args.names
    else:
        print("usage: make_skill_zip.py <skill> [<skill> ...] | --all")
        sys.exit(1)

    for n in names:
        make_zip(n)


if __name__ == "__main__":
    main()
