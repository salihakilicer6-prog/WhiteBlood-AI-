#!/usr/bin/env python3
"""Generate SVG + PNG icons (macOS SF-style stroke, 24x24) and emit Assets.luau.

Usage:
    python3 assets/make_icons.py

Outputs:
    assets/icons/*.svg          hand-authored source SVGs
    assets/icons/*.png          4x rasterized PNGs (100x100)
    assets/Assets.luau          module: name -> { svg, png (base64) }
"""
import base64
import io
import os
import re

from cairosvg import svg2png

HERE = os.path.dirname(os.path.abspath(__file__))
SVG_DIR = os.path.join(HERE, "icons")
OUT_LUAU = os.path.join(HERE, "Assets.luau")
SIZE = 100  # 24 * 4 retina-ish
STROKE = 3.0
COLOR = "currentColor"

TPL = """<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="{stroke}" stroke-linecap="round" stroke-linejoin="round">{body}</svg>"""


def body(p):
    return p


ICONS = {
    # window controls (macOS traffic lights are drawn as circles in UI, not these)
    "close": body('<path d="M6 6l12 12M18 6L6 18"/>'),
    "minimize": body('<path d="M5 12h14"/>'),
    "maximize": body('<rect x="5" y="5" width="14" height="14" rx="2.5"/>'),
    "send": body('<path d="M4 12l16-7-6 16-2-7z"/><path d="M12 14l8-9"/>'),
    "settings": body(
        '<circle cx="12" cy="12" r="3.2"/>'
        '<path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1.03 1.56V21a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1.11-1.56 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.56-1.03H3a2 2 0 1 1 0-4h.09a1.7 1.7 0 0 0 1.56-1.11 1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.7 1.7 0 0 0 1.87.34h.01a1.7 1.7 0 0 0 1.03-1.56V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1.03 1.56h.01a1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87v.01a1.7 1.7 0 0 0 1.56 1.03H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.56 1.03z"/>'
    ),
    "folder": body('<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>'),
    "file": body('<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>'),
    "terminal": body('<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M7 9l3 3-3 3M12 15h5"/>'),
    "console": body('<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M7 9l3 3-3 3M12 15h5"/>'),
    "search": body('<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.5-4.5"/>'),
    "trash": body('<path d="M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2M6.5 7l1 12a2 2 0 0 0 2 1.9h5a2 2 0 0 0 2-1.9l1-12"/><path d="M10 11v6M14 11v6"/>'),
    "refresh": body('<path d="M20 12a8 8 0 1 1-2.3-5.6"/><path d="M20 3v4h-4"/>'),
    "plus": body('<path d="M12 5v14M5 12h14"/>'),
    "download": body('<path d="M12 3v12M7 11l5 5 5-5"/><path d="M5 20h14"/>'),
    "play": body('<path d="M7 4.5v15l13-7.5z"/>'),
    "stop": body('<rect x="6" y="6" width="12" height="12" rx="2.5"/>'),
    "pencil": body('<path d="M4 20l1-4L16.5 4.5a2.1 2.1 0 0 1 3 3L8 19l-4 1z"/><path d="M14 7l3 3"/>'),
    "edit": body('<path d="M4 20l1-4L16.5 4.5a2.1 2.1 0 0 1 3 3L8 19l-4 1z"/><path d="M14 7l3 3"/>'),
    "gear": body(
        '<circle cx="12" cy="12" r="3.2"/>'
        '<path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1.03 1.56V21a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1.11-1.56 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.56-1.03H3a2 2 0 1 1 0-4h.09a1.7 1.7 0 0 0 1.56-1.11 1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.7 1.7 0 0 0 1.87.34h.01a1.7 1.7 0 0 0 1.03-1.56V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1.03 1.56h.01a1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87v.01a1.7 1.7 0 0 0 1.56 1.03H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.56 1.03z"/>'
    ),
    "sparkles": body('<path d="M12 3l1.8 4.8L18.5 9.5l-4.7 1.7L12 16l-1.8-4.8L5.5 9.5l4.7-1.7z"/><path d="M19 14l.9 2.4 2.1.6-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.6z"/>'),
    "chat": body('<path d="M4 6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H9l-5 4z"/>'),
    "code": body('<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M13 5l-2 14"/>'),
    "branch": body('<circle cx="6" cy="6" r="2.5"/><circle cx="6" cy="18" r="2.5"/><circle cx="18" cy="8" r="2.5"/><path d="M6 8.5v7M18 10.5c0 3-3 3.5-6 3.5"/>'),
    "sun": body('<circle cx="12" cy="12" r="4.5"/><path d="M12 2.5V5M12 19v2.5M2.5 12H5M19 12h2.5M4.8 4.8l1.8 1.8M17.4 17.4l1.8 1.8M4.8 19.2l1.8-1.8M17.4 6.6l1.8-1.8"/>'),
    "moon": body('<path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z"/>'),
    "key": body('<circle cx="8" cy="15" r="4"/><path d="M11 12l8-8M17 4l3 3M14 7l2 2"/>'),
    "robot": body('<rect x="5" y="8" width="14" height="11" rx="2.5"/><circle cx="9" cy="13" r="1.2"/><circle cx="15" cy="13" r="1.2"/><path d="M9 16.5h6M12 3v3M5 12H3M19 12h2"/>'),
    "wrench": body('<path d="M14.5 6.5a4.5 4.5 0 0 0-6 6L4 17l3 3 4.5-4.5a4.5 4.5 0 0 0 6-6L14.5 12.5 11.5 9.5z"/>'),
    "info": body('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8v.5"/>'),
    "alert": body('<path d="M12 3l9 17H3z"/><path d="M12 10v4M12 17v.5"/>'),
    "check": body('<path d="M4.5 12.5l5 5 10-11"/>'),
    "x": body('<path d="M6 6l12 12M18 6L6 18"/>'),
    "chevronRight": body('<path d="M9 5l7 7-7 7"/>'),
    "chevronDown": body('<path d="M5 9l7 7 7-7"/>'),
    "more": body('<circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/>'),
    "copy": body('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>'),
    "github": body('<path d="M12 3a9 9 0 0 0-3 17.5c.5.1.7-.2.7-.5v-1.7c-2.7.6-3.3-1.3-3.3-1.3-.4-1.1-1-1.4-1-1.4-.9-.6.1-.6.1-.6 1 .1 1.5 1 1.5 1 .9 1.5 2.3 1.1 2.9.8.1-.6.3-1.1.6-1.3-2.2-.3-4.5-1.1-4.5-4.9 0-1.1.4-2 1-2.7-.1-.3-.4-1.3.1-2.7 0 0 .8-.3 2.7 1a9.3 9.3 0 0 1 5 0c1.9-1.3 2.7-1 2.7-1 .5 1.4.2 2.4.1 2.7.6.7 1 1.6 1 2.7 0 3.8-2.3 4.6-4.5 4.9.3.3.6.8.6 1.7v2.5c0 .3.2.6.7.5A9 9 0 0 0 12 3z"/>'),
    "globe": body('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18z"/>'),
    "image": body('<rect x="3" y="5" width="18" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.5"/><path d="M5 17l5-5 3 3 2-2 4 4"/>'),
    "tag": body('<path d="M4 4h7l9 9-7 7-9-9z"/><circle cx="8.5" cy="8.5" r="1.2"/>'),
}


def svg_for(name, path):
    return TPL.format(color=COLOR, stroke=STROKE, body=path)


# -- Button textures -----------------------------------------------------------
# 9-slice button surface, drawn in white so the UI can tint it with any color
# via ImageColor3. Vertical gloss: bright hairline on top fading to a soft
# translucent body - reads as a "glass" button on top of the liquid panels.
TEX_SIZE = 96          # 24 * 4 (retina-ish)
TEX_SLICE = 24         # distance from each edge; corners stay rounded
TEX_RADIUS = 24        # corner radius in texture pixels

TEX_TPL = """<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{w}" viewBox="0 0 {w} {w}">
<defs>
<linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
<stop offset="0" stop-color="#ffffff" stop-opacity="0.50"/>
<stop offset="0.45" stop-color="#ffffff" stop-opacity="0.26"/>
<stop offset="1" stop-color="#ffffff" stop-opacity="0.10"/>
</linearGradient>
<linearGradient id="e" x1="0" y1="0" x2="0" y2="1">
<stop offset="0" stop-color="#ffffff" stop-opacity="0.45"/>
<stop offset="1" stop-color="#ffffff" stop-opacity="0.10"/>
</linearGradient>
</defs>
<rect x="0" y="0" width="{w}" height="{w}" rx="{r}" fill="url(#g)"/>
<rect x="1.5" y="1.5" width="{w}-3" height="{w}-3" rx="{r}-2" fill="none" stroke="url(#e)" stroke-width="2.5"/>
</svg>"""

# Textures to generate: name -> True. All share the same gloss shape.
TEXTURES = {
    "buttonGloss": True,
}


def write_textures():
    tex_dir = os.path.join(HERE, "textures")
    os.makedirs(tex_dir, exist_ok=True)
    for name in sorted(TEXTURES):
        svg = TEX_TPL.format(w=TEX_SIZE, r=TEX_RADIUS)
        png = svg2png(bytestring=svg.encode(), output_width=TEX_SIZE, output_height=TEX_SIZE)
        with open(os.path.join(tex_dir, name + ".png"), "wb") as f:
            f.write(png)
        print(f"  tex {name}: {len(png)} bytes")


def main():
    os.makedirs(SVG_DIR, exist_ok=True)
    icons = {}
    for name in sorted(ICONS):
        svg = svg_for(name, ICONS[name])
        svg_path = os.path.join(SVG_DIR, name + ".svg")
        with open(svg_path, "w") as f:
            f.write(svg)
        png = svg2png(bytestring=svg.encode(), output_width=SIZE, output_height=SIZE)
        png_path = os.path.join(SVG_DIR, name + ".png")
        with open(png_path, "wb") as f:
            f.write(png)
        icons[name] = {
            "svg": svg,
            "png": base64.b64encode(png).decode("ascii"),
        }
        print(f"  {name}: {len(png)} bytes")

    lines = []
    lines.append("--!strict")
    lines.append("-- Generated by assets/make_icons.py. Do not edit by hand.")
    lines.append("local Assets: { [string]: { svg: string, png: string } } = {")
    for name, data in icons.items():
        lines.append(f'\t{name} = {{')
        lines.append(f'\t\tsvg = {json_encode(data["svg"])},')
        lines.append(f'\t\tpng = {json_encode(data["png"])},')
        lines.append(f'\t}},')
    lines.append("}")
    lines.append("return Assets")
    with open(OUT_LUAU, "w") as f:
        f.write("\n".join(lines) + "\n")
    print(f"Wrote {OUT_LUAU} ({len(icons)} icons)")

    write_textures()


def json_encode(s):
    # minimal Lua-string-safe JSON (handles the chars we use)
    s = s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\t", "\\t")
    s = re.sub(r"[\x00-\x1f]", lambda m: "\\u%04x" % ord(m.group(0)), s)
    return '"' + s + '"'


if __name__ == "__main__":
    main()
