# OpenCodeLuau

An AI coding agent that runs **inside Roblox** (Studio Lite). It gives you a
macOS-style floating window in-game with a chat, a Luau editor, a file tree, a
console, installable skills, and a settings pane. The agent talks to any
OpenAI-compatible API and acts on your game through tools (`run_luau`,
`insert_part`, `find_first_child`, file/console access, ...).

No emojis. All icons are embedded as SVG->PNG base64 assets, so the bundle is a
single self-contained `.luau` file you load with your executor's `loadstring`.

```
                                  OpenCodeLuau
                     (macOS floating window, draggable + resizable)
   +----------------------+-----------------------------------------------+
   |  OpenCode            |  Chat                                        |
   |  Luau agent in Roblox|  [Ask the agent... ]                         |
   |                      |                                               |
   |  Chat          (o)   |  You: build a red pyramid in Workspace       |
   |  Console       (o)   |  Agent: <streaming tokens>                   |
   |  Files         (o)   |                                               |
   |  Editor        (o)   |                                               |
   |  Skills        (o)   |                                               |
   |  Settings      (o)   |                                               |
   +----------------------+-----------------------------------------------+
```

## Features

- **Floating window** - macOS traffic lights, drag by titlebar, resize from the
  bottom-right corner, maximize to the viewport, minimize.
- **Chat** - streaming assistant replies (markdown rendered as rich text),
  role-colored bubbles, auto-scroll.
- **Agent loop** - tool calling with up to `maxIterations` rounds per turn.
  Model replies stream; every tool call is shown in the chat as it runs.
- **Tools** - run Luau in the live game, insert/create instances, find or
  explore the instance tree, set properties, read the game console, read/write
  files, list/make folders, get game info, fetch URLs.
- **Skills** - install skills from `.zip` URLs (like `npm install <pkg>`).
  Each skill's `SKILL.md` instructions are injected into the system prompt so
  the agent knows how to apply it. Ships with a `creator-dashboard` example.
- **Files / Editor** - browse the executor's `opencode/` workspace and edit
  Luau with syntax-highlighted preview.
- **Console** - live game console with severity filter and auto-refresh.
- **Settings** - base URL, API key, model; works with local servers
  (LM Studio, Ollama, vLLM) that expose `/v1/chat/completions`.
- **Sessions** - conversation history persists under `opencode/sessions/`.
- **Mobile / compact** - on phones (touch input or a small viewport) the UI
  switches to a compact layout: the sidebar becomes an icon-only rail, the
  window fills the viewport, and touch targets grow.

## Quick start

1. Build the bundle (see below), host `dist/Main.luau` somewhere reachable by
   your executor (e.g. GitHub Pages, a CDN, a gist, or paste it inline).
2. In Roblox, run:

   ```lua
   loadstring(game:HttpGet("https://raw.githubusercontent.com/article-hub-studio/OpenCode/main/dist/Main.luau"))()
   ```

   (Fallback, if raw is blocked: `https://github.com/article-hub-studio/OpenCode/releases/latest/download/Main.luau`)

   The bundle is built from `src/Entry.luau`, so it **auto-starts** on load:
   the window opens immediately and a small status label + console prints
   (`OpenCode: OpenCode v0.3.5 loading...`, `... ready`) give you instant
   feedback. If anything fails, a red `OpenCode ERROR: ...` line appears on
   screen and in the executor console.

3. Open **Settings**, paste your API key (or point `Base URL` at a local
   server), pick a model, and hit **Test connection**.
4. Ask the agent something, e.g. *"make a red pyramid in Workspace"*.

### Programmatic start

You can also drive it from your own script (useful for executors that do not
support the auto-start entry):

```lua
local Entry = loadstring(game:HttpGet("https://raw.githubusercontent.com/article-hub-studio/OpenCode/main/dist/Main.luau"))()
local Main = Entry.Main          -- the underlying module
local app = Main.start(nil, {
    width = 720,
    height = 520,
    session = "my-session",   -- conversation id for persistence
    maxIterations = 12,       -- max tool rounds per turn
    compact = true,           -- force the compact phone layout
})
```

Note that the bundled file already auto-starts, so calling `Entry.start` or
`Main.start` again returns the running instance without opening a second
window. With no `parent`, `Main.start` hosts the window in `PlayerGui` (falls
back to `CoreGui`).

## Configuration

Settings persist to `opencode/config.json` in the executor workspace. The
shape is the same as [`config.example.json`](config.example.json):

| Key           | Type   | Default                       | Meaning                              |
| ------------- | ------ | ----------------------------- | ------------------------------------ |
| `baseUrl`     | string | `https://api.openai.com/v1`   | OpenAI-compatible API root           |
| `apiKey`      | string | `""`                          | Bearer token (empty for local)       |
| `model`       | string | `gpt-4o-mini`                 | Model id                             |
| `temperature` | number | `0.4`                         | Sampling temperature                 |
| `maxTokens`   | number | `4096`                        | Max completion tokens                |

Any OpenAI-compatible endpoint works. For a local model with no key:

```json
{
  "baseUrl": "http://localhost:1234/v1",
  "apiKey": "",
  "model": "local-model"
}
```

`config.json` is read on startup (`Main.start`) and written by the Settings
view's **Save**. You can also pre-seed it via the Files/Editor views before
talking to the agent.

## Tools the agent can use

| Tool                    | Purpose                                              |
| ----------------------- | ---------------------------------------------------- |
| `run_luau`              | Execute Luau in the live game (captures `print`)     |
| `insert_part`           | Create a Part/Instance with position, size, color... |
| `create_instance`       | Create arbitrary instances (Script, Model, GUI, ...) |
| `find_first_child`      | Find instances by name or dotted path                |
| `explore_instance`      | List children of a path (like `ls`)                  |
| `set_instance_property` | Change a property on an instance                     |
| `get_console`           | Read recent game console output                      |
| `read_file`             | Read a file from the executor workspace              |
| `write_file`            | Write a file                                         |
| `list_files`            | List a directory                                     |
| `make_folder`           | Create a folder                                      |
| `get_game_info`         | Game/server/place info                               |
| `http_get`              | Fetch a URL (subject to executor policy)             |

## Skills

Skills are markdown instruction packs installed from `.zip` URLs. They live
under `opencode/skills/<name>/`. A skill is any zip with a `SKILL.md` at its
root (or inside a single top-level folder, which becomes the skill name):

```
creator-dashboard/
├── SKILL.md                    # frontmatter + instructions
└── scripts/
    └── build_dashboard.luau    # helper scripts the agent can read/run
```

`SKILL.md` uses a minimal frontmatter block:

```md
---
title: Creator Dashboard
description: Build a dashboard overlay for the game.
version: 1.0.0
---

# Creator Dashboard

When the user asks to build a dashboard, use `scripts/build_dashboard.luau` ...

## Requirements
- All instances created via run_luau or insert_part.
```

On install, the `instruction` body is appended to the agent's system prompt, so
installed skills guide every subsequent turn. Install from the **Skills** view
(paste a URL) or programmatically:

```lua
local Skill = require("Agent/Skill")
local meta, err = Skill.install("https://your-host/skills/creator-dashboard.zip")
```

To package a skill folder as a zip:

```sh
python3 tools/make_skill_zip.py --all          # zips skills/* -> dist/skills/
python3 tools/make_skill_zip.py creator-dashboard
```

The bundled example skill `creator-dashboard` builds a resizable stats + quick
actions panel (spawn/reset parts) in the game.

## Building from source

Requirements: [darklua](https://darklua.com) for bundling, and a Luau toolchain
(`luau`, `luau-analyze`) for tests.

```sh
# Bundle the app (src/Entry.luau + all its requires) into one loadable file.
# Entry auto-starts Main on load, so loadstring(...)() just works.
darklua process src/Entry.luau dist/Main.luau
# or
./build.sh          # darklua must be on PATH; DARKLUA=/path/darklua ./build.sh

# Bundle + run a test entry (darklua follows the test's requires into src/).
darklua process tests/test_agent.luau dist/test_agent.luau
luau dist/test_agent.luau
```

The bundle config lives in `.darklua.json` and uses darklua's `path` require
mode, so every `require("./...")` / `require("../...")` is resolved to its
source file and inlined into a single file.

### Layout

```
src/
  Entry.luau         # auto-start wrapper: calls Main.start on load + debug prints
  Main.luau          # bootstrap: window, sidebar, view switching, agent wiring
  Core/Device.luau   # device detection + shared GUI host resolution
  Core/Debug.luau    # debug console + in-game status label (top-left)
  AI/Provider.luau   # OpenAI-compatible chat-completions client (streaming)
  Agent/Agent.luau   # agent loop (tool calling, events)
  Agent/Tools.luau   # tool definitions + executor
  Agent/Skill.luau   # skill install/list/buildInstructions
  Agent/Session.luau # conversation persistence
  Agent/Context.luau # system prompt builder
  Core/FS.luau       # workspace file system (memory-backed fallback)
  Core/Net.luau      # HTTP client (mockable in tests)
  Core/JSON.luau     # pure-Luau JSON encode/decode
  Core/Base64.luau   # base64 codec
  Core/Inflate.luau  # zlib inflate
  Core/Zip.luau      # zip reader
  Core/Console.luau  # game console reader
  UI/Theme.luau      # macOS dark palette, fonts, sizes
  UI/Ui.luau         # declarative builder (camelCase -> PascalCase mapping)
  UI/Components.luau # button, input, scroll, dropdown, checkbox, toast
  UI/IconManager.luau# embedded SVG->PNG icon loader
  UI/Markdown.luau   # markdown -> rich text
  UI/Window.luau     # macOS window chrome
  UI/Views/*.luau    # Chat, Console, Files, Editor, Settings, Skills
assets/Assets.luau   # generated icon assets (svg + png base64)
tests/               # bundle-based tests + mock_roblox.luau
tools/make_skill_zip.py
build.sh             # darklua bundle script
.darklua.json        # darklua bundling config
```

## Testing

Tests run against a hand-rolled `mock_roblox.luau` (Instances, Signals,
Color3, Enum, UDim2, task, ...) so the whole UI and agent can run in the Luau
CLI outside Roblox.

```sh
# Each test entry pulls in the modules it needs; darklua bundles them.
for t in test_agent test_ui test_components test_window test_views test_main test_entry; do
  darklua process tests/$t.luau dist/test_$t.luau
  luau dist/test_$t.luau | tail -1
done
```

`luau-analyze` is useful, but it reports unknown Roblox globals (`game`,
`Instance`, `Color3`, ...) when run outside a Roblox-aware environment. Those
warnings are expected; the type errors that matter are resolved before
shipping.

## Security notes

- `run_luau` executes arbitrary code **in your game**. Only use executors and
  APIs you trust.
- The API key is stored as plaintext in `opencode/config.json` (executor
  workspace). Do not share your workspace or logs.
- Skills are unzipped zip archives; review the `SKILL.md` of third-party skills
  before installing. Path traversal in skill names is stripped on install.
- `http_get` and the provider requests are subject to your executor's network
  policy and Roblox HTTP allow-list.
