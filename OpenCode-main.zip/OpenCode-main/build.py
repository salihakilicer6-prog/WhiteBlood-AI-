#!/usr/bin/env python3
"""Bundle the OpenCodeLuau src tree into a single loadable .luau file.

Executors load one script (via loadstring). This tool inlines every module
under one or more source roots plus a runtime `require` shim, producing a
single .luau file.

Usage:
    python3 build.py [--entry Main] [--out dist/OpenCodeLuau.luau] [--src-dir src ...]
"""
import argparse
import os
import re
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))

MODULE_RE = re.compile(r'require\(\s*"([^"]+)"\s*\)')

HEADER = """--!strict
-- OpenCodeLuau: AI coding agent inside Roblox (Studio Lite)
-- Bundled by build.py. Load this file with your executor's loadstring.
-- UI: macOS-style floating window. No emojis; all icons drawn as SVG -> PNG
-- and embedded as base64. Skills install from .zip URLs (unzip in pure Luau).

local __OpenCodeLuau = {}
local __loaders = {}

local function __require(name)
	local cached = __OpenCodeLuau[name]
	if cached ~= nil then
		return cached
	end
	local loader = __loaders[name]
	if loader == nil then
		error("module not found: " .. name, 2)
	end
	local value = loader()
	if value == nil then
		value = true
	end
	__OpenCodeLuau[name] = value
	return value
end
"""

LOADER_TAIL = """
-- Install the shim as the global require where possible (executor env).
local ok_install, _ = pcall(function()
	_G.require = __require
end)
if not ok_install then
	-- Read-only _G (standalone luau CLI): fall back to getfenv(0).
	pcall(function()
		getfenv(0).require = __require
	end)
end

local result = __require(%s)

return result
"""


def collect_modules(src_dirs):
    """Return { moduleName: filePath } with forward-slash normalized paths.

    Names are relative to the project root (dir of build.py) so that a
    `require("../src/Core/Util")` written for the standalone tree resolves
    to the same name in the bundle.
    """
    modules = {}
    for src in src_dirs:
        src = os.path.abspath(src)
        for dirpath, _, filenames in os.walk(src):
            for fn in sorted(filenames):
                if not fn.endswith((".luau", ".lua")):
                    continue
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, ROOT)
                name = rel.replace(os.sep, "/")
                name = name[:-5] if name.endswith(".luau") else name[:-4]
                modules[name] = full
    return modules


def resolve(modules, from_name, target):
    """Resolve a require target relative to a module name."""
    if target.startswith("./") or target.startswith("../"):
        base = os.path.dirname(from_name)
        parts = target.split("/")
        parts = [p for p in parts if p not in (".", "")]
        cur = base.split("/") if base else []
        for p in parts:
            if p == "..":
                if cur:
                    cur.pop()
            else:
                cur.append(p)
        resolved = "/".join(cur)
    else:
        resolved = target
    return resolved if resolved in modules else resolved


def topo_sort(modules):
    order = []
    visiting = set()
    visited = set()

    def visit(name):
        if name in visited:
            return
        if name in visiting:
            return
        visiting.add(name)
        src = open(modules[name]).read()
        for m in MODULE_RE.finditer(src):
            dep = resolve(modules, name, m.group(1))
            if dep in modules:
                visit(dep)
        visiting.discard(name)
        visited.add(name)
        order.append(name)

    for name in modules:
        visit(name)
    return order


def rewrite_requires(modules, name):
    """Return module source with every require("X") rewritten to
    __require("<resolved module name>") so the runtime shim finds loaders."""
    src = open(modules[name]).read()
    return MODULE_RE.sub(
        lambda m: '__require("%s")' % resolve(modules, name, m.group(1)), src
    )


def build(entry, out_path, src_dirs):
    modules = collect_modules(src_dirs)
    if not modules:
        print("error: no modules found")
        sys.exit(1)
    if entry not in modules:
        # try prefixing with each src root's basename (e.g. --entry test_agent)
        matched = None
        for src in src_dirs:
            cand = os.path.relpath(os.path.abspath(src), ROOT) + "/" + entry
            cand = cand.replace(os.sep, "/")
            if cand in modules:
                matched = cand
                break
        if matched is None:
            print(f"error: entry module '{entry}' not found (have: {sorted(modules)[:5]}...)")
            sys.exit(1)
        entry = matched

    order = topo_sort(modules)
    if entry in order:
        order.remove(entry)
    order.append(entry)

    parts = [HEADER]
    for name in order:
        src = rewrite_requires(modules, name)
        parts.append(f'__loaders[{json_repr(name)}] = function()\n')
        parts.append(f'-- [module] {name}\n')
        parts.append(src)
        parts.append('\nend\n')
    parts.append(LOADER_TAIL % json_repr(entry))

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w") as f:
        f.write("".join(parts))
    print(f"bundled {len(order)} modules -> {out_path} ({os.path.getsize(out_path)} bytes)")
    return out_path


def json_repr(s):
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--entry", default="Main")
    ap.add_argument("--out", default="dist/OpenCodeLuau.luau")
    ap.add_argument("--src-dir", action="append", default=None)
    args = ap.parse_args()
    src_dirs = args.src_dir or [os.path.join(ROOT, "src")]
    build(args.entry, args.out, src_dirs)


if __name__ == "__main__":
    main()
