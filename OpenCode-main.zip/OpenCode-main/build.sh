#!/usr/bin/env bash
# Build OpenCode into a single loadable file using darklua.
# Entry is src/Entry.luau (auto-start wrapper) so the output boots on load.
# Usage: ./build.sh            (darklua must be on PATH)
#        DARKLUA=/path/darklua ./build.sh
set -euo pipefail

DARKLUA="${DARKLUA:-darklua}"
ENTRY="src/Entry.luau"
OUT="dist/Main.luau"

mkdir -p dist
"$DARKLUA" process "$ENTRY" "$OUT"
echo "built $OUT ($(wc -c < "$OUT") bytes)"
